import Image from 'next/image';
import { useState } from 'react';

export default function HomePage() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [status, setStatus] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('Enviando...');
    try {
      const res = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setStatus('Mensagem enviada com sucesso!');
        setFormData({ name: '', email: '', phone: '', message: '' });
      } else {
        setStatus('Erro ao enviar. Tente novamente.');
      }
    } catch (err) {
      setStatus('Erro ao enviar.');
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <section className="bg-gray-900 text-white py-20 px-6 text-center">
        <div className="flex justify-center mb-6">
          <Image
            src="/logo.jpg"
            alt="Logo"
            width={120}
            height={120}
            className="object-contain drop-shadow-lg"
            style={{ backgroundColor: 'transparent' }}
          />
        </div>
        <h1 className="text-4xl font-bold mb-4">José Alencar & Advogados Associados</h1>
        <p className="text-lg">Atuação jurídica completa com excelência, ética e resultados.</p>
        <button className="mt-6 px-6 py-3 bg-white text-gray-900 font-semibold rounded-2xl shadow-md hover:bg-gray-100">Agende sua consulta</button>
      </section>

      <section className="py-16 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">Áreas de Atuação</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {['Previdenciário', 'Criminal', 'Trabalhista', 'Cível', 'Empresarial', 'Imobiliário'].map(area => (
            <div key={area} className="p-6 border rounded-2xl shadow hover:shadow-lg transition">
              <h3 className="text-xl font-semibold mb-2">{area}</h3>
              <p>Atendimento especializado para demandas jurídicas na área de {area.toLowerCase()}.</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-gray-100 py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Sobre o Escritório</h2>
          <p>
            Fundado com o compromisso de oferecer assessoria jurídica de qualidade, o escritório José Alencar & Advogados Associados atua com ética, dedicação e profundo conhecimento em diversas áreas do Direito. Nossa equipe está preparada para atender com excelência tanto pessoas físicas quanto jurídicas.
          </p>
        </div>
      </section>

      <section className="py-16 px-6 text-center">
        <h2 className="text-3xl font-bold mb-6">Fale Conosco</h2>
        <p className="mb-8">Entre em contato para agendar sua consulta ou tirar dúvidas.</p>
        <form onSubmit={handleSubmit} className="max-w-xl mx-auto text-left space-y-4">
          <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Nome" className="w-full p-3 border rounded-xl" required />
          <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="E-mail" className="w-full p-3 border rounded-xl" required />
          <input type="tel" name="phone" value={formData.phone} onChange={handleChange} placeholder="Telefone" className="w-full p-3 border rounded-xl" />
          <textarea name="message" value={formData.message} onChange={handleChange} placeholder="Mensagem" className="w-full p-3 border rounded-xl h-32" required></textarea>
          <button type="submit" className="w-full bg-gray-900 text-white py-3 rounded-xl hover:bg-gray-800">Enviar Mensagem</button>
          {status && <p className="text-center text-sm pt-2">{status}</p>}
        </form>
        <div className="mt-6">
          <a href="https://wa.me/5587991389215" target="_blank" rel="noopener noreferrer" className="inline-block mt-4 px-6 py-3 bg-green-600 text-white rounded-2xl shadow hover:bg-green-700">
            Fale pelo WhatsApp
          </a>
        </div>
      </section>

      <footer className="bg-gray-900 text-white text-sm text-center py-6">
        <p>© 2026 José Alencar & Advogados Associados. Todos os direitos reservados.</p>
        <p>OAB / Cumprimos rigorosamente o Código de Ética da Advocacia.</p>
      </footer>
    </div>
  );
}
